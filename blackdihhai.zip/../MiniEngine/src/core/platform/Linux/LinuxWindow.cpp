#ifndef LINUXWINDOW_CPP
#define LINUXWINDOW_CPP

#include "LinuxWindow.h"

namespace MiniEngine
{
}

#endif /* LINUXWINDOW_CPP */
